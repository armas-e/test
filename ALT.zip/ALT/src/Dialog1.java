//package tree;
//
//import javax.swing.JFrame;
//import javax.swing.JOptionPane;
//import javax.swing.JTextField;
//
//public class Dialog1 {  
//JFrame f1;  
//Dialog1(){  
//	f1=new JFrame();   
//	
//    String shr = JOptionPane.showInputDialog(f1,"Enter Hour:");
//    String smin = JOptionPane.showInputDialog(f1,"Enter Min:");
//    
//    alarm1.hour = Integer.parseInt(shr);
//    alarm1.min = Integer.parseInt(smin);
//    f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//}  
//}